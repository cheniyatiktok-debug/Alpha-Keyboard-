# Alpha Keyboard V2

A native Android Input Method Editor (IME) for English and direct Sinhala Unicode typing. V2 refreshes the companion app, adds eight keyboard color themes, introduces a new Alpha logo/app icon, expands the Sinhala key layout, and improves Backspace behavior for selections, Unicode code points, and grapheme clusters.

## V2 highlights

- Updated setup and personalization screen with a modern dark-violet Alpha brand.
- Eight local keyboard themes: Midnight, Ocean, Orchid, Cloud, Forest, Sunset, Rose, and Graphite.
- Custom key-highlight colors and optional photo backgrounds are retained.
- New vector logo and adaptive launcher icon; no external image downloads are needed.
- Expanded Sinhala character and vowel-sign keys.
- Backspace first deletes selected text, then attempts ICU character-boundary deletion so Sinhala combining sequences are less likely to be split. Editor-specific behavior can still vary, so test in the apps you use.
- Version code 2 / version name 2.0.
- GitHub Actions workflow builds a debug APK directly from the repository root and uploads it as an artifact.

## Build using GitHub Actions from an Android phone

1. Upload or push the **contents of this project folder** to your GitHub repository. The `.github/workflows/android-build.yml` workflow is included at the repository root.
2. Open the repository on GitHub and go to **Actions**.
3. Select **Build Alpha Keyboard V2 APK**, then tap **Run workflow**. A push to `main` or `master` also starts a build.
4. When the workflow completes, open the run and download the `Alpha-Keyboard-V2-APK` artifact. Unzip the artifact to get `Alpha-Keyboard-V2-debug.apk`.
5. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from the app you used to open the APK.
6. Open Alpha Keyboard V2, tap **Enable keyboard**, enable it in Android settings, then tap **Choose keyboard** and select Alpha Keyboard.

## Build locally

Requirements: JDK 17, Android SDK Platform 35, Android Build Tools 35.0.0, and Gradle 8.9.

From the project root:

```bash
gradle --no-daemon assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Privacy

- No `INTERNET` permission is requested.
- Typed text is not collected, logged, transmitted, or saved by this app.
- Theme, accent, and selected photo URI are stored locally.
- Photo backgrounds are disabled in password fields.
- The photo itself is not copied into app storage.
- The standard Android third-party-keyboard warning is expected when enabling any IME.

## Important testing notes

This environment does not have the Android SDK or Gradle installed, so an APK could not be built here. GitHub Actions installs the required build tools and builds the project. After building, test English and Sinhala typing, cursor movement, deletion of Sinhala combinations, password fields, theme switching, photo access, and keyboard switching on your target phone. Sinhala typing is direct Unicode key entry; it is not phonetic transliteration or predictive text.
