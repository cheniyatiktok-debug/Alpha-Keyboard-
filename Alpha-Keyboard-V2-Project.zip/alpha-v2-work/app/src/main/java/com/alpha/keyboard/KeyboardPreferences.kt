package com.alpha.keyboard

import android.content.Context

object KeyboardPreferences {
    private const val FILE_NAME = "alpha_keyboard_settings"
    private const val KEY_THEME = "theme"
    private const val KEY_PHOTO_URI = "photo_uri"
    private const val KEY_CUSTOM_ACCENT = "custom_accent"

    data class Theme(
        val id: String,
        val title: String,
        val background: Int,
        val key: Int,
        val accent: Int,
        val text: Int = 0xFFFFFFFF.toInt()
    )

    val themes = listOf(
        Theme("midnight", "Midnight", 0xFF171A35.toInt(), 0xFF282B4B.toInt(), 0xFF7168FF.toInt()),
        Theme("ocean", "Ocean", 0xFF102D4A.toInt(), 0xFF20486A.toInt(), 0xFF39B9F2.toInt()),
        Theme("orchid", "Orchid", 0xFF291A3E.toInt(), 0xFF44305F.toInt(), 0xFFBD72F5.toInt()),
        Theme("light", "Cloud", 0xFFE7EAF6.toInt(), 0xFFFFFFFF.toInt(), 0xFF655CE8.toInt(), 0xFF24243B.toInt()),
        Theme("forest", "Forest", 0xFF102A24.toInt(), 0xFF1D4035.toInt(), 0xFF43C59E.toInt()),
        Theme("sunset", "Sunset", 0xFF321D2A.toInt(), 0xFF503044.toInt(), 0xFFFF8A65.toInt()),
        Theme("rose", "Rose", 0xFF351C2B.toInt(), 0xFF543044.toInt(), 0xFFFF6FAE.toInt()),
        Theme("graphite", "Graphite", 0xFF202327.toInt(), 0xFF343940.toInt(), 0xFFB4C5D3.toInt())
    )

    fun selectedTheme(context: Context): Theme {
        val id = preferences(context).getString(KEY_THEME, "midnight")
        val base = themes.firstOrNull { it.id == id } ?: themes.first()
        return base.copy(accent = preferences(context).getInt(KEY_CUSTOM_ACCENT, base.accent))
    }

    fun selectTheme(context: Context, id: String) {
        if (themes.any { it.id == id }) {
            preferences(context).edit().putString(KEY_THEME, id).apply()
        }
    }

    fun photoUri(context: Context): String? =
        preferences(context).getString(KEY_PHOTO_URI, null)

    fun setPhotoUri(context: Context, uri: String?) {
        preferences(context).edit().putString(KEY_PHOTO_URI, uri).apply()
    }

    fun setCustomAccent(context: Context, color: Int) {
        preferences(context).edit().putInt(KEY_CUSTOM_ACCENT, color).apply()
    }

    private fun preferences(context: Context) =
        context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
}
