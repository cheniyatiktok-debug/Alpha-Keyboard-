package com.alpha.keyboard

import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView
import java.text.BreakIterator
import java.util.Locale

class AlphaKeyboardService : InputMethodService() {
    private var language = Language.ENGLISH
    private var shifted = false
    private var symbols = false
    private var passwordField = false

    private enum class Language { ENGLISH, SINHALA }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        val inputType = attribute?.inputType ?: InputType.TYPE_NULL
        val variation = inputType and InputType.TYPE_MASK_VARIATION
        val textPassword = (inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT &&
            (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)
        val numberPassword = (inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER &&
            variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
        passwordField = textPassword || numberPassword
    }

    override fun onCreateInputView(): View = buildKeyboard()

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        setInputView(buildKeyboard())
    }

    private fun buildKeyboard(): View {
        val theme = KeyboardPreferences.selectedTheme(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(7), dp(5), dp(9))
            background = GradientDrawable().apply {
                setColor(theme.background)
                cornerRadius = dp(17).toFloat()
            }
        }

        if (!passwordField && KeyboardPreferences.photoUri(this) != null) {
            try {
                val uri = android.net.Uri.parse(KeyboardPreferences.photoUri(this))
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                val targetWidth = resources.displayMetrics.widthPixels.coerceAtLeast(1)
                val targetHeight = dp(260).coerceAtLeast(1)
                var sample = 1
                while (bounds.outWidth / sample > targetWidth * 2 ||
                    bounds.outHeight / sample > targetHeight * 2) {
                    sample *= 2
                }
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                val bitmap = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, options)
                }
                if (bitmap != null) {
                    root.background = android.graphics.drawable.BitmapDrawable(resources, bitmap).apply {
                        alpha = 105
                    }
                }
            } catch (_: Exception) {
                // A photo can be removed or become unavailable; the selected color theme remains usable.
            }
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        toolbar.addView(keyButton(if (language == Language.ENGLISH) "EN · English" else "සිං · Sinhala", theme, true) {
            language = if (language == Language.ENGLISH) Language.SINHALA else Language.ENGLISH
            shifted = false
            symbols = false
            setInputView(buildKeyboard())
        }, LinearLayout.LayoutParams(0, dp(39), 3f).apply {
            setMargins(dp(2), 0, dp(2), dp(3))
        })
        toolbar.addView(keyButton("⌫", theme, false) { deletePreviousCharacter() }, toolbarControl())
        toolbar.addView(keyButton("↵", theme, false) { enter() }, toolbarControl())
        root.addView(toolbar)

        val rows = if (symbols) {
            listOf(
                listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                listOf("@", "#", "\$", "%", "&", "-", "+", "(", ")"),
                listOf("=", "*", "\"", "'", ":", ";", "!", "?", "⌫"),
                listOf("ABC", ",", "🌐", "space", ".", "↵")
            )
        } else if (language == Language.ENGLISH) {
            listOf(
                listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
                listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
                listOf("⇧", "z", "x", "c", "v", "b", "n", "m", "⌫"),
                listOf("?123", ",", "🌐", "space", ".", "↵")
            )
        } else {
            listOf(
                listOf("අ", "ආ", "ඇ", "ඈ", "ඉ", "ඊ", "උ", "ඌ", "එ", "ඒ"),
                listOf("ක", "ග", "ච", "ජ", "ට", "ඩ", "ත", "ද", "න"),
                listOf("ප", "බ", "ම", "ය", "ර", "ල", "ව", "⌫"),
                listOf("්", "ි", "ී", "ු", "ූ", "ෙ", "ේ", "ො", "ෝ", "ං"),
                listOf("?123", ",", "🌐", "space", ".", "↵")
            )
        }

        rows.forEach { row ->
            val rowView = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { key ->
                val weight = when (key) {
                    "space" -> 3.7f
                    "⇧", "⌫", "↵", "?123" -> 1.5f
                    "🌐" -> 1.4f
                    else -> 1f
                }
                rowView.addView(keyButton(key, theme, key == "space") {
                    handleKey(key)
                }, LinearLayout.LayoutParams(0, dp(43), weight).apply {
                    setMargins(dp(2), dp(3), dp(2), dp(3))
                })
            }
            root.addView(rowView)
        }
        return root
    }

    private fun handleKey(key: String) {
        when (key) {
            "⇧" -> {
                shifted = !shifted
                setInputView(buildKeyboard())
            }
            "⌫" -> deletePreviousCharacter()
            "↵" -> enter()
            "space" -> currentInputConnection?.commitText(" ", 1)
            "🌐" -> {
                language = if (language == Language.ENGLISH) Language.SINHALA else Language.ENGLISH
                shifted = false
                symbols = false
                setInputView(buildKeyboard())
            }
            "?123" -> {
                symbols = true
                setInputView(buildKeyboard())
            }
            "ABC" -> {
                symbols = false
                setInputView(buildKeyboard())
            }
            else -> {
                val text = if (language == Language.ENGLISH && shifted) key.uppercase(Locale.ROOT) else key
                currentInputConnection?.commitText(text, 1)
                if (shifted && language == Language.ENGLISH) {
                    shifted = false
                    setInputView(buildKeyboard())
                }
            }
        }
    }

    private fun deletePreviousCharacter() {
        val connection = currentInputConnection ?: return
        val before = connection.getTextBeforeCursor(32, 0)?.toString().orEmpty()
        if (before.isEmpty()) {
            connection.deleteSurroundingText(1, 0)
            return
        }
        val iterator = BreakIterator.getCharacterInstance()
        iterator.setText(before)
        val boundary = iterator.preceding(before.length)
        val units = if (boundary == BreakIterator.DONE) 1 else before.length - boundary
        connection.deleteSurroundingText(units, 0)
    }

    private fun enter() {
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
            ?: EditorInfo.IME_ACTION_NONE
        val connection = currentInputConnection ?: return
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            connection.performEditorAction(action)
        } else {
            connection.commitText("\n", 1)
        }
    }

    private fun keyButton(
        text: String,
        theme: KeyboardPreferences.Theme,
        isSpecial: Boolean,
        action: () -> Unit
    ) = TextView(this).apply {
        this.text = if (text == "space") "English · Sinhala"
            else if (language == Language.ENGLISH && shifted && text.length == 1 && text[0].isLetter()) text.uppercase(Locale.ROOT)
            else text
        textSize = if (text == "space") 12f else if (text.length > 2) 13f else 18f
        gravity = Gravity.CENTER
        setTextColor(theme.text)
        if (text.length == 1 || text == "⇧") setTypeface(typeface, Typeface.BOLD)
        background = GradientDrawable().apply {
            setColor(if (isSpecial) theme.accent else theme.key)
            cornerRadius = dp(9).toFloat()
        }
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }

    private fun toolbarControl() = LinearLayout.LayoutParams(0, dp(39), 1f).apply {
        setMargins(dp(2), 0, dp(2), dp(3))
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
