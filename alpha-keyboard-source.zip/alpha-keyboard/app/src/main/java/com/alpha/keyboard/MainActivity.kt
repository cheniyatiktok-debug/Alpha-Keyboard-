package com.alpha.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val ink = Color.rgb(28, 28, 48)
    private val muted = Color.rgb(103, 106, 130)
    private val violet = Color.rgb(96, 83, 229)
    private val page = Color.rgb(245, 246, 252)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20, 23, 48)
        window.navigationBarColor = Color.rgb(20, 23, 48)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) render()
    }

    private fun render() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(page)
            isFillViewport = true
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(34))
        }
        scroll.addView(content)
        setContentView(scroll)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(23))
            background = rounded(0xFF25215A.toInt(), 26)
        }
        hero.addView(label("ALPHA KEYBOARD", 12, 0xFFC9C4FF.toInt(), true))
        hero.addView(label("Your words,\nyour style.", 30, Color.WHITE, true).apply {
            setPadding(0, dp(12), 0, dp(7))
        })
        hero.addView(label("A Sinhala + English keyboard designed around your privacy.", 15, 0xFFE2E1F3.toInt()))
        content.addView(hero, matchWrap())

        sectionTitle("Get started")
        val enabled = isKeyboardEnabled()
        val active = card()
        active.addView(label(if (enabled) "Keyboard enabled" else "Enable Alpha Keyboard", 18, ink, true))
        active.addView(label(
            if (enabled) "Choose Alpha Keyboard as your current keyboard to start typing."
            else "Android asks you to enable keyboards in system settings. Your choice stays on this device.",
            14, muted
        ).apply { setPadding(0, dp(7), 0, dp(15)) })
        active.addView(actionButton(if (enabled) "Choose keyboard" else "Enable keyboard") {
            if (enabled) {
                val manager = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                manager.showInputMethodPicker()
            } else {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })
        content.addView(active, matchWrap())

        sectionTitle("Personalize your keyboard")
        val themesCard = card()
        themesCard.addView(label("Color theme", 17, ink, true))
        themesCard.addView(label("Choose a look. It is saved only on this device.", 13, muted).apply {
            setPadding(0, dp(4), 0, dp(13))
        })
        val selected = KeyboardPreferences.selectedTheme(this)
        KeyboardPreferences.themes.forEach { theme ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = rounded(if (theme.id == selected.id) 0xFFEDEBFF.toInt() else Color.WHITE, 14)
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    KeyboardPreferences.selectTheme(this@MainActivity, theme.id)
                    render()
                }
            }
            val swatch = View(this).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(theme.background, theme.accent)
                ).apply { cornerRadius = dp(20).toFloat() }
            }
            row.addView(swatch, LinearLayout.LayoutParams(dp(38), dp(30)))
            row.addView(label(theme.title, 15, ink, true).apply {
                setPadding(dp(12), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label(if (theme.id == selected.id) "Selected" else "", 12, violet, true))
            val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }
            themesCard.addView(row, params)
        }
        themesCard.addView(label("Key highlight color", 14, ink, true).apply {
            setPadding(0, dp(8), 0, dp(8))
        })
        val accents = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val accentColors = listOf(
            0xFF7168FF.toInt(), 0xFF39B9F2.toInt(), 0xFFBD72F5.toInt(),
            0xFFFF6B9D.toInt(), 0xFF30B88A.toInt(), 0xFFFFA348.toInt()
        )
        accentColors.forEach { color ->
            val chip = View(this).apply {
                background = GradientDrawable().apply {
                    setColor(color)
                    setStroke(dp(2), Color.WHITE)
                    cornerRadius = dp(30).toFloat()
                }
                isClickable = true
                isFocusable = true
                contentDescription = "Set key highlight color"
                setOnClickListener {
                    KeyboardPreferences.setCustomAccent(this@MainActivity, color)
                    render()
                }
            }
            accents.addView(chip, LinearLayout.LayoutParams(dp(34), dp(34)).apply {
                marginEnd = dp(10)
            })
        }
        themesCard.addView(accents)
        themesCard.addView(actionButton("Use a photo background") { choosePhoto() })
        KeyboardPreferences.photoUri(this)?.let {
            val photoActions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(9), 0, 0)
            }
            photoActions.addView(label("Photo selected · stored on this device", 12, muted),
                LinearLayout.LayoutParams(0, -2, 1f))
            photoActions.addView(actionButton("Remove") {
                try {
                    contentResolver.releasePersistableUriPermission(
                        Uri.parse(it),
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: SecurityException) {
                    // Removing the local preference still works if Android already revoked access.
                }
                KeyboardPreferences.setPhotoUri(this@MainActivity, null)
                render()
            })
            themesCard.addView(photoActions)
        }
        content.addView(themesCard, matchWrap())

        sectionTitle("Privacy")
        val privacy = card()
        privacy.addView(label("Your typing stays yours", 17, ink, true))
        privacy.addView(label(
            "Alpha Keyboard does not request internet access, record or store keystrokes, " +
                "save passwords, or send what you type anywhere. Theme choices and the selected photo reference " +
                "are kept locally on this device. Android may show a standard warning when a keyboard is enabled.",
            14, muted
        ).apply { setPadding(0, dp(7), 0, 0) })
        content.addView(privacy, matchWrap())

        sectionTitle("About")
        val about = card()
        about.addView(label("English + සිංහල", 16, ink, true))
        about.addView(label(
            "Switch languages from the keyboard’s language button. This first version uses direct Sinhala script keys.",
            14, muted
        ).apply { setPadding(0, dp(6), 0, 0) })
        content.addView(about, matchWrap())
    }

    private fun choosePhoto() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_PHOTO)
    }

    @Deprecated("The document picker result is used to persist read access to the selected image.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PHOTO && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                KeyboardPreferences.setPhotoUri(this, uri.toString())
                render()
            } catch (_: SecurityException) {
                KeyboardPreferences.setPhotoUri(this, null)
            }
        }
    }

    private fun isKeyboardEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_INPUT_METHODS) ?: return false
        return enabled.contains(packageName)
    }

    private fun sectionTitle(text: String) {
        content.addView(label(text, 19, ink, true).apply {
            setPadding(dp(2), dp(22), 0, dp(10))
        })
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(17), dp(17), dp(17), dp(17))
        background = rounded(Color.WHITE, 20)
        elevation = dp(2).toFloat()
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.START
            setLineSpacing(dp(2).toFloat(), 1f)
        }

    private fun actionButton(text: String, action: () -> Unit) =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background = rounded(violet, 14)
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setOnClickListener { action() }
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply {
        bottomMargin = dp(12)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_PHOTO = 301
    }
}
